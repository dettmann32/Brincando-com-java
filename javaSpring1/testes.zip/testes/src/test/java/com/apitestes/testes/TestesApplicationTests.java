package com.apitestes.testes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestesApplicationTests {

	@Test
	void contextLoads() {
	}

}
